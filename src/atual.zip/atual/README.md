# Aplicação móvel Melhor Idade

O objetivo deste projeto é a criação de uma aplicação móvel de fácil acesso para pessoas da terceira idade, com o intuito de melhorar a qualidade de vida dos usuários através de funcionalidades que irão auxiliá-los em seu dia-a-dia.

Para mais informações, acesse: [GitHub repo](https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2023-1-e3-proj-mov-t4-melhor-idade).
